####### Tutorial on microbiome data analysis ##########
## By: Carly Muletz Wolz

## Great website for stats guidance: GUSTA ME (http://mb3is.megx.net/gustame)
## Helpful papers: Ramette 2007 https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2121141/
## Paliy & Shankar 2016: https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4769650/


library(ape)
library(phyloseq)
library(ggplot2)
library(vegan)
library(geomorph)

setwd("/Users/Carly/Dropbox (Smithsonian)/Metabarcode_wrksp/R_files/")
setwd("/Users/genetics/Downloads/R_files/")

######### Biom file  #######
biom <-  import_biom("otu_table_SMP_all.biom") 

#### Tree file #####
tree <- read.tree("SMP_rooted_all_Dec2015.tre")

##### Mapping file ####
map <- import_qiime_sample_data("SMP_runall_Map_alpha.txt")

## Merge into phyloseq object
Sal_bac_final <- merge_phyloseq(biom, tree, map)

#########################    DATA ANALYSIS   ####################################

## Following analyses in Muletz Wolz et al. 2017: https://www.ncbi.nlm.nih.gov/pubmed/28682480
## In the analyses, I separated the dataset into two parts
## A co-occurring species dataset in which I sampled co-occurring species at three parks, with 1-2 sites per park
## An elevation dataset in which I sampled 1 species along an elevational gradient


####################  Co-occurring dataset analyses #########################
## The objective here was to:
## to determine the relative contribution of host species versus shared environment 
## in shaping skin microbiomes of sympatric species

Co_occur <- subset_samples(Sal_bac_final, Site.sp_compare == "Y")

## Because we subsetted some taxa are still present even though they don't have any sequences
sum(taxa_sums(Co_occur) == 0)
## Let's remove them in case they cause problems somewhere
Co_occur = filter_taxa(Co_occur, function(x) sum(x) != 0, TRUE)
sum(taxa_sums(Co_occur) == 0)

## Phyloseq objects are complex (Sal_bac_final), many of the packages just need a regular ole' data.frame
Co_df <- as(sample_data(Co_occur), "data.frame")

head(Co_df)

################  Beta-diversity stats ################

## Beta diversity is how different each sample is from one another in composition
## The composition can be based on whether OTUs are present or absent (Jaccard and other unweighted metrics)
## or on the OTUs presencd-absence AND their abundances (Bray-curtis and other weighted metrics)
## Beta diversity can be represented in many ways and the term has several different definitions
## in community ecology, it's kind of messy
## If interested this is probably one of the best papers to start with:
## Anderson et al. 2011: https://www.ncbi.nlm.nih.gov/pubmed/21070562


## From paper: "For beta-diversity we used Jaccard and unweighted Unifrac (Lozupone et al.
## 2011), and we also performed abundance-weighted analyses using Bray-Curtis distances from
## normalized sequence counts. To generate normalized sequence counts, we performed variance-
## stabilizing normalization on the raw sequence counts (Paulson et al. 2013) using the functions
## cumNormStatFast and cumNorm in the package ‘metagenomeSeq’ (Paulson et al. 2015). This
## normalization method corrects for biases associated with uneven sequencing depth (Paulson et
## al. 2013; McMurdie & Holmes 2014).

## See Extra_normalization.R on how to do this, or you can use rarefaction
## Both have their own issues and it is best to do what is right for your data

## generate your distance matrices on the phyloseq object

## Jaccard distances
jacc <- distance(Co_occur, "jaccard", binary = T)


######   SIDENOTE on beta-diversity distance matrix calculations

## Let's look at the distance matrix, each sample is compared to every other sample
jacc2 <- as.matrix(jacc)
jacc2[1:5,1:5]

## jaccard is calculated by the number of species that two samples share, let's say 2
## divided by the total number of species in the two samples you are comparing 
## minus the # of species they share, then substract 1
## Comparison 1: Let's say 4 species in sample A and 6 species in sample B, in which
## 2 species (3,4) are shared

## Sample A [1,2,3,4] and Sample B [3,4,5,6,7,8,9,10]

1-2/(10-2)

## Comparison 2: Let's say 6 species in sample A and 5 species in sample B, in which
## 4 species (3,4,5,6) are shared

## Sample A [1,2,3,4,5,6] and Sample B [3,4,5,6,7,8,9,10,11]

1-4/(11-4)

## So, smaller values indicate more similarity, and larger values indicate more dissimilarity

## Unifrac distances
## http://mmg-233-2013-genetics-genomics.wikia.com/wiki/Unifrac
uni <- distance(Co_occur, method = "unifrac")

## Bray curtis distance
## Bray is similar to jaccard, but incorporates abundance
bray <- distance(Co_occur, method = "bray")

## Ordinate the distances using Principal coordinate analysis
## This determines the coordinates in space that represents the 
## dissimilarity of samples from one another 
## Let's use the GUSTAME website to learn more:
## https://mb3is.megx.net/gustame/dissimilarity-based-methods/principal-coordinates-analysis
jacc.ord <-ordinate(Co_occur, method = "PCoA", jacc)
uni.ord <- ordinate(Co_occur, method = "PCoA", uni)
bray.ord <-ordinate(Co_occur, method = "PCoA", bray)

## Using the phyloseq package you can use several different
## methods to ordinate your data, PCoA and NMDS are the most common
?ordinate

## Let's look at the data first with our focus on species and site

## You are using a phyloseq command here that uses ggplot2, so all ggplot2 modifiers work
## ggplot2 is awesome! and well-documented on how to edit figures: http://www.cookbook-r.com/Graphs/
plot_jacc <- plot_ordination(Co_occur, jacc.ord, shape = "Species", color = "Site")

## Default plotting parameters are not so great
plot_jacc

## change factor level of sites, so that it follows an order
## FDR was the one site at Catoctin MP, LSB and RSB were sampling sites at Shenandoah NP
## NRA and RIM were sampling sites at Mt. Rogers. We will also rename them 
## when we plot them later on so they are more informative to someone else other than me!
levels(sample_data(Co_occur)$Site)
sample_data(Co_occur)$Site <- factor(sample_data(Co_occur)$Site, levels = c("FDR", "LSB", "RSB", "NRA", "RIM"))
levels(sample_data(Co_occur)$Site)

plot_jacc

## We have to re-run plotting the ordination to have the order take effect
plot_jacc <- plot_ordination(Co_occur, jacc.ord, shape = "Species", color = "Site")

## Let's not look too much at this yet, it's ugly so let's clean it up with some ggplot2 modifiers
plot_jacc

#################    PLOTTING SIDENOTE    ########################

## Looking better, use the same colors as in the alpha-diversity plots and label the sites
plot_jacc + theme_bw() + theme_classic() + theme(text = element_text(size = 16))  + 
  scale_color_manual(values = c( "midnightblue",  "purple2","coral", "turquoise", "yellow2"), 
                     labels = c("Catoctin", "Shenandoah1", "Shenandoah2", "Mt.Rogers1", "Mt.Rogers2"))  

## Make the point sizes larger
plot_jacc + theme_bw() + theme_classic() + theme(text = element_text(size = 16))  + 
  scale_color_manual(values = c( "midnightblue",  "purple2","coral", "turquoise", "yellow2"), 
                     labels = c("Catoctin", "Shenandoah1", "Shenandoah2", "Mt.Rogers1", "Mt.Rogers2")) +
  geom_point(size = 4)

## Italicize and correct the species names and add the confidence ellipses
plot_jacc + theme_bw() + theme_classic() + theme(text = element_text(size = 16))  + 
  scale_color_manual(values = c( "midnightblue",  "purple2","coral", "turquoise", "yellow2"), 
                     labels = c("Catoctin", "Shenandoah1", "Shenandoah2", "Mt.Rogers1", "Mt.Rogers2")) +
  geom_point(size = 4) + scale_shape_manual(values = c(15, 16, 17),
  labels = c(expression(italic('P. cinereus')), (expression(italic("P. cylindraceus"))), 
  (expression(italic("P. glutinosus")))))  + stat_ellipse (mapping = aes(group = Site)) 

## Then the species names look weird, ugh. Googled search and added this last line. Beautiful!
plot_jacc + theme_bw() + theme_classic() + theme(text = element_text(size = 16))  + 
  scale_color_manual(values = c( "midnightblue",  "purple2","coral", "turquoise", "yellow2"), 
                     labels = c("Catoctin", "Shenandoah1", "Shenandoah2", "Mt.Rogers1", "Mt.Rogers2")) +
  geom_point(size = 4) + scale_shape_manual(values = c(15, 16, 17),
  labels = c(expression(italic('P. cinereus')), (expression(italic("P. cylindraceus"))), 
  (expression(italic("P. glutinosus")))))  + stat_ellipse (mapping = aes(group = Site)) + 
  theme(legend.key = element_blank(), legend.text.align = 0)


##########  WHAT DO WE SEE?    #######
## Co-occurring species at Shenandoah are distinct for the individuals sampled at Catoctin
## And Mt. Rogers. But the amount of variation explained in the first two axes is low
## What do the other beta-diversity metrics (Bray-Curtis and Unifrac) show us?

plot_bray <- plot_ordination(Co_occur, bray.ord, shape = "Species", color = "Site")

plot_bray + theme_bw() + theme_classic() + theme(text = element_text(size = 16))  + 
  scale_color_manual(values = c( "midnightblue",  "purple2","coral", "turquoise", "yellow2"), 
                     labels = c("Catoctin", "Shenandoah1", "Shenandoah2", "Mt.Rogers1", "Mt.Rogers2")) +
  geom_point(size = 4) + scale_shape_manual(values = c(15, 16, 17),
  labels = c(expression(italic('P. cinereus')), (expression(italic("P. cylindraceus"))), 
  (expression(italic("P. glutinosus")))))  + stat_ellipse (mapping = aes(group = Site)) + 
  theme(legend.key = element_blank(), legend.text.align = 0)

##### Using an abundance-weighted metric explains much more of the variation in the first two
## axes, and we see the same trend. How about unifrac?

plot_unifrac <- plot_ordination(Co_occur, uni.ord, shape = "Species", color = "Site")

plot_unifrac + theme_bw() + theme_classic() + theme(text = element_text(size = 16))  + 
  scale_color_manual(values = c( "midnightblue",  "purple2","coral", "turquoise", "yellow2"), 
                     labels = c("Catoctin", "Shenandoah1", "Shenandoah2", "Mt.Rogers1", "Mt.Rogers2")) +
  geom_point(size = 4) + scale_shape_manual(values = c(15, 16, 17),
  labels = c(expression(italic('P. cinereus')), (expression(italic("P. cylindraceus"))), 
  (expression(italic("P. glutinosus")))))  + stat_ellipse (mapping = aes(group = Site)) + 
  theme(legend.key = element_blank(), legend.text.align = 0)

###### GENERALLY, we see similar separation of Shenandoah salamanders from the others
## And that co-occurring species do not differ in their microbiome. This was surprising
## We expected co-occurring species to differ in their microbiome as most studies to 
## date have found this in multiple vertebrate taxa including amphibians
## I'm exploring the role of skin antimicrobial peptides in shaping the microbiome
## I hypothesize that AMPs are similar among these congeneric species


## Now what do the stats tell us?


########################       PERMANOVA in vegan      #########################
## From paper: "For beta-diversity, we used PERMANOVAs (Anderson 2001) in the package ‘vegan’ 
## (Oksanen et al. 2015) and included the
## same categorical explanatory variables as in the alpha-diversity analysis"

## We will use the package vegan to do this, this uses a dataframe we created earlier, Co_df
head(Co_df)

## We use the function adonis to run a PERMANOVA
?adonis

## adonis2 is a new funciton, need to look more into this...

## We have both environment and host factors of interest
## The main variables of interest are site and species and we put them first
## It is important to try to have a balanced design as PERMANOVAs are sensitive to 
## sample size, see more about this below in DISPERSION sidenote

## sample sizes of salamanders per species-site combination
table(Co_df$Site.sp)
## Not balanced, but the best we could do...cylindraceus is a rare species at Shenandoah NP

adonis_j1 <- adonis(jacc ~ Site + Species + sex + BodyCon + Leaf.litter, data = Co_df)
adonis_j1
## Only site is significant, adonis uses type I ss so order matters, 
## Let's move around the variables to make sure significant variables are still important

adonis_j2 <- adonis(jacc ~ Species + sex + BodyCon +Site + Leaf.litter, data = Co_df)
adonis_j2
## Species is now significant (but doesn't look like it in the plot), 
## Site remains significant when moved around

adonis_j3 <- adonis(jacc ~  sex + BodyCon + Species + Site + Leaf.litter, data = Co_df)
adonis_j3
## Site still significant, a couple others significant as well
## Site should be the first factor as it appears to explain the most variation (see R2)

adonis_j4 <- adonis(jacc ~   Site + Species  + Leaf.litter + sex + BodyCon, data = Co_df)
adonis_j4
## When you put site first it removes the significance of species, so species is sharing the variation
## with site, and once that variation is removed species is no longer significant

####### CONCLUSION: Site is the only significant factor for jaccard beta-diversity

adonis_b1 <- adonis(bray ~ Site + Species + SoilpH + sex + BodyCon + Leaf.litter, data = Co_df)
adonis_b1

adonis_b2 <- adonis(bray ~ Species + Site  + SoilpH + sex + BodyCon + Leaf.litter, data = Co_df)
adonis_b2
## This happens again, but we know that Site is explaining the variation.

### WE already plotted it and the visualization also confirms the stats 

plot_jacc + theme_bw() + theme(text = element_text(size = 16)) + geom_point(size = 4)
plot_bray + theme_bw() + theme(text = element_text(size = 16)) + geom_point(size = 4)

## From paper: "We performed post-hoc analyses using PERMANOVAs, and corrected p-values 
## for multiple comparisons using FDR corrections." 

## To do so I had to subset every pairwise site combo, and test for differences
## I recently was trained on how to conduct PERMANOVAs using the package geomorph
## And you can do pairwise comparisons with this package with no need to subset

##############      PERMANOVA in geomorph to get pairwise     ###################


## Make a geomorph data frame
Co.gdf<-geomorph.data.frame(jacc=jacc,uni = uni, bray = bray,
    Site=Co_df$Site,Species=Co_df$Species, Sex = Co_df$sex, BodyCon = Co_df$BodyCon, 
    Leaf.litter = Co_df$Leaf.litter)

## verify correct factor and numeric designations
str(Co.gdf)
# PERMANOVA comparing community composition
?procD.lm

## Can be used for any distance matrix, best to use 10000 iterations (permutations),
## but for the rest we will use the default of 999 
proc_jacc <- procD.lm(jacc~Site+Species+Sex +BodyCon + Leaf.litter ,data=Co.gdf, iter = 9999)
proc_jacc

## move sex and it isn't significant now
proc_jacc2 <-procD.lm(jacc~Sex + Site+Species+BodyCon + Leaf.litter ,data=Co.gdf)
proc_jacc2

proc_uni <- procD.lm(uni~Site+Species+Sex+BodyCon + Leaf.litter ,data=Co.gdf)
proc_uni

## move sex and it isn't significant now
proc_uni2 <-procD.lm(uni~Sex + Site+Species+BodyCon + Leaf.litter ,data=Co.gdf)
proc_uni2

proc_bray <- procD.lm(bray~Site+Species+Sex+BodyCon + Leaf.litter ,data=Co.gdf)
proc_bray
## Oh jeezzz, now remember that the PERMANOVA did not show this

proc_bray2 <- procD.lm(bray~BodyCon+ Species+Site+Sex + Leaf.litter ,data=Co.gdf)
proc_bray2

## These are likely not significant on their own, let's look, at each one and 
## compare it to the null model, for instance Sex

pw_bray_sex <- advanced.procD.lm(bray~Sex,~1, groups = ~Sex, data = Co.gdf)
summary(pw_bray_sex)
## At the top we can see that sex is not a significant variable compared to the null model
## Best practice is to graph
## and think about if the stats make sense for what you see

plot_bray_sex <- plot_ordination(Co_occur, bray.ord, color = "sex")
plot_bray_sex + theme_bw() + theme(text = element_text(size = 16)) + geom_point(size = 4) + 
  stat_ellipse (mapping = aes(group = sex))

###############     DISPERSION SIDENOTE    ######################

######### NOTE: Dispersion of beta-diversity, another form of beta-diversity
## For sex, it looks like is there is differences in dispersion of the data here



## If the PERMANOVA returns a significant results it could be because the 
## dispersion is different AND/OR the centroid is different. This is similar to an 
## ANOVA where significance can be driven by mean or variance of the data.
## For an unbalanced design, if you have significantly different dispersion 
## you cannot determine statistically (as far as I know) if the centroid position is different
## See Anderson & Walsh 2013: http://onlinelibrary.wiley.com/doi/10.1890/12-2010.1/abstract
## I use visualization of data to determine if centroid is different. 
## For sites, the centroid positions for the two sites at Shenandoah NP (LSB and RSB) clearly 
## look far away from the centroid positions of the other three sites
## I also did a PERMDISP to examine dispersion, but did not report it in the manuscript
## See Extra_PERMDISP.R on how to do these analyses


plot_jacc + theme_bw() + theme(text = element_text(size = 16)) + geom_point(size = 4) +
  stat_ellipse (mapping = aes(group = Site))

## The dispersion is telling you how diverse the community is for the factor level (e.g., Site or Sex)
## compared to all the other replicates of that particular factor
## For site, LSB has greater variation in the bacterial community present than RIM

## The centroid is telling you how distinct the community at a particular site is
## compared to all other sites

## Let's finish our original objective to do pairwise comparisons of Site

pw_jacc_site <- advanced.procD.lm(jacc~Site,~1, groups = ~Site, data = Co.gdf)
summary(pw_jacc_site)
pw_uni_Site <- advanced.procD.lm(uni~Site,~1, groups = ~Site, data = Co.gdf)
summary(pw_uni_Site)


######## OUR conclusion from the PERMANOVA is:
## "we found support for a site effect on beta-diversity: skin microbiomes from individuals at Shenandoah NP
## were consistently different in bacterial composition compared to those at Catoctin MP and Mt.
## Rogers NRA (Jaccard, Unifrac and Bray-Curtis, PERMANOVA: p < 0.05), regardless of host
## species (Figure 2; PERMANOVA: p > 0.05)."  



####################  Elevation dataset analyses #########################
## The objective here was to:
## to determine whether elevation can predict microbiome structure

Elev <- subset_samples(Sal_bac_final, Species == "cinereus" & Park == "Shenandoah")


## Because we subsetted some taxa are still present even though they don't have any sequences
sum(taxa_sums(Elev) == 0)
## Let's remove them in case they cause problems somewhere
Elev = filter_taxa(Elev, function(x) sum(x) != 0, TRUE)
sum(taxa_sums(Elev) == 0)


## Make dataframe
Ele_df <- as(sample_data(Elev), "data.frame")

##jaccard distances
jacc_ele <- distance(Elev, "jaccard", binary = T)
jacc_ele.ord <-ordinate(Elev, method = "PCoA", jacc_ele)

## From paper: "For beta-diversity, we computed partial Mantel
## correlations between compositional dissimilarity matrices (Jaccard and Unifrac) and an
## elevational distance matrix after accounting for spatial distance between sites using 10,000
## permutations in the package ‘vegan’ (Oksanen et al. 2015). 

## Distance matrix for elevation 
ele.dist <- as.matrix(dist(Ele_df$Elevation, method = "euclidean"))

## Distance between sites
dist_degrees <- as.matrix(dist(cbind(Ele_df$GPS_W, Ele_df$GPS_N)))

## Partial mantel
mantel.partial(jacc_ele, ele.dist, dist_degrees, method = "pearson", permutations = 10000)

## From paper: "For beta-diversity, we found a relationship with elevation, after
## accounting for distances among sites (partial Mantel: Jaccard, p = 0.035, R2 = 9%...)"

## Plotting axis 1 of PCoA against elevation

## Make plots with pc axis 1
p_pcoa <- pcoa(jacc_ele)

str(p_pcoa$vectors)

## Coordinates for axis 1
pc1 <- p_pcoa$vectors[,1]
pc1

## Add to our dataframe
Ele_df  <- cbind(Ele_df, pc1)


plot_ele <-  ggplot(data = Ele_df, aes(x = Elevation, y = pc1)) +theme_bw()+ theme_classic() + 
  stat_smooth(method = lm, se = T, color = "black") + geom_point() + 
  theme(text = element_text(size = 16)) + xlab("\nElevation (m)") +
  ylab("Principal coordinate axis 1\n") + xlim(690, 1000) 

plot_ele

## There are other ways to plot this, but this was the best I could come up with at the time!





