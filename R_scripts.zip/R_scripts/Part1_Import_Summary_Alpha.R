####### Tutorial on bringing in microbiome data and performing summary stats with files generated from QIIME ##########
## By: Carly Muletz Wolz


## NOTE: this script was developed based on 16S rRNA amplicon high-throughput sequencing
## It will work on other metabarcoding datatypes, but the files you bring in my need to
## be modified manually to get in the correct format
## see Import_other_data_files.R to see how to get other possible datatypes into the correct format

## Load all the packages we will need
## You should have installed them all with the Install_packages.R file

library(ape)
library(phyloseq)
library(plyr)
library(ggplot2)
library(picante)

## Create a folder on your computer where you would like to store 
## all the files and output for this tutorial
## DOWNLOAD all the files we will need at https://github.com/SmithsonianWorkshops/metabarcoding
## into this folder

## Set your working directory to the folder where you downloaded the files
## There are a few options here, but I find the absolute path is the best
## That way you can always remember where you files are

## Get your working directory to help you set the path
getwd()

setwd("/Users/genetics/Downloads/R_files/")

### FOR QIIME, we need three files: a biom file, a tree file and a mapping file
## Some help on phyloseq here: 
## http://evomics.org/wp-content/uploads/2016/01/phyloseq-Lab-00-Answers.html
## https://joey711.github.io/phyloseq/import-data.html

## We will bring in two sets of each file type.  
## One from a recent publication Muletz-Wolz et al. 2017: http://onlinelibrary.wiley.com/doi/10.1111/1365-2656.12726/full
## We will analyze this data as in the publication
## These files were generated using QIIME 1.9 and differ from the new QIIME 2.0 format

## A second set that I exported from the 'moving pictures' tutorial from QIIME 2.0
## these files are all called _QIIME2_tutorial and are to illustrate that you have 
## to be prepared for new versions of packages to bring changes to how your data looks
## and how you bring it into R. 
## Phyloseq on github is a good place to ask questions if you run into new issues
## https://github.com/joey711/phyloseq/issues


#######################    BIOM FILE   #########################


## This biom file was created with QIIME 1.9 and the taxonomy and OTU table were together
## No error message here
biom <-  import_biom("otu_table_SMP_all.biom") 

## In QIIME 2.0, to get the biom file in correct format for Phyloseq, I followed this:
## https://forum.qiime2.org/t/is-there-any-way-to-summarize-taxa-plot-by-category/446/2
## You need to have the OTU table and the taxonomic assignments in the biom file
biom_QIIME2_tutorial <- import_biom("table-with-taxonomy.biom")
## Warning message doesn't seem to be a problem

## Not informative ranks of taxonomy
rank_names(biom)

## We can see what the levels are for each rank based on the k__, p__, c__ notations that greengenes uses
## This taxonomic assignments will likely change if working with 18S or COI, or other amplicons
tax_table(biom)[1:5, 1:7]

## Add OTU_ID to taxonomy table
tax_table(biom) <- cbind(tax_table(biom), rownames(tax_table(biom)))

## Specify the column names
colnames(tax_table(biom)) <- c("Kingdom", "Phylum", "Class", "Order", "Family", "Genus", "Species", "OTUID")


rank_names(biom)
tax_table(biom)[1:5, 1:8]

## NOTE: the OTU_table in phyloseq is a species x site matrix. Most ecologists work with 
## a site x species matrix, so be aware of this if you are bringing in data generated
## not in QIIME, see Import_other_data_files.R to see how to get your data into the correct format

otu_table(biom)[1:5, 1:5]


### QIIME 2.0 assigns OTUs with a bunch of letters and numbers now....
otu_table(biom_QIIME2_tutorial)[1:5, 1:5]


####################### TREE FILE ###########################

## QIIME 1.9 .tre file
tree <- read.tree("SMP_rooted_all_Dec2015.tre")

## QIIME 2.0 .nwk file
tree_QIIME2_tutorial <- read.tree("tree.nwk")

## both are rooted and you need a rooted tree for phyloseq 
is.rooted(tree)
is.rooted(tree_QIIME2_tutorial)

## If your tree is unrooted, the easiest and the choice used by QIIME is to randomly 
## root your tree, 
?root

## You would run this to do so and then use the tree_rooted to merge with your other files
## tree_rooted = root(tree, 1, resolve.root = T)

## Or to use an outgroup, I added the 16S sequence for Archaea_M21087 ((GenBank accession #M21087)
## to my fasta file before I created the tree in QIIME with fasttree
## (I removed ~300 bp at beginning and end of sequence since the primers I used amplified 
## the central region of the 16S rRNA gene) 
## You would run these two lines:
## tree_root <- root(tree, outgroup = "'Archaea_M21087'", resolve.root = TRUE)
## tree_final <-(drop.tip(tree_root, "'Archaea_M21087'"))

## Look at the tree
?plot.phylo
plot(tree, show.tip.label = F)



#########################    METADATA      ###################################
## NOTE: R hates numbers as an ID for samples. It will put an X. in front of numbers
## this can cause all types of irriations
## Just DON'T use a number for your first part of the ID: A1.1 is preferred to 1.1 for example
## See import_other_data_files.R for how to deal with number as ID issues

map <- import_qiime_sample_data("SMP_runall_Map.txt")

map_QIIME2_tutorial <- import_qiime_sample_data("sample-metadata.tsv")

## You can click on the map file in the Global Environment window to see the data
## You can run commands also to look at the mapping files
sample_variables(map)
sample_variables(map_QIIME2_tutorial)

###################### MERGE it all together! ######################

Sal_bac <- merge_phyloseq(biom, tree, map)

## Overview on what's all there now
Sal_bac

## Let's look at the data a bit more, and what happened when we merged
## number of taxa in original biom file
ntaxa(biom)
## number of taxa in merged file
ntaxa(Sal_bac)
## There is less taxa here because we merged the biom file with the tree file
## I was confused when I realized this happened the first time
## When I went back and looked at the tree file when I created it in QIIME
## I learned that some of the OTUs were failing alignment and therefore not in the tree
## When I looked at the OTU table they were often assigned as 'unclassified' in the taxonomy file


## For instance OTU_118 and OTU_150 was in the original biom file, but failed alignment and 
## therefore is not in the tree file
any(c("OTU_118", "OTU_150") %in% as(tax_table(biom), "matrix")[1:400,8])
any(c("OTU_118", "OTU_150") %in% as(tax_table(Sal_bac), "matrix")[1:400,8])

## Subset it to look at, you see that when assigned taxonomy, the assigner was not able to come up with
## much information, this is usually a red flag

biom.subset <- subset_taxa(biom, rownames(tax_table(biom)) %in% c("OTU_118", "OTU_150"))
tax_table(biom.subset)

## Maybe with QIIME 2.0 this won't be as much of a problem...
tutorial <- merge_phyloseq(biom_QIIME2_tutorial, tree_QIIME2_tutorial, map_QIIME2_tutorial)
## number of taxa in original biom file
ntaxa(biom_QIIME2_tutorial)
## number of taxa in merged file
ntaxa(tutorial)

## The last housekeeping item, before summary stats

sample_names(Sal_bac)
## I ran PCR negative controls with each set of samples that I extracted in a batch
## I converted my biom file to .txt file, see QIIME notes on how to do that
## And manually removed OTUs that were of concern = present in all negative controls
## These are subjective decisions you will have to make for yourself -- good luck!

Sal_bac

## Let's remove the negative control samples from the analyses. They are not needed now
## The NCs had NAs in all variables, so just choosing one variable
Sal_bac_final <- subset_samples(Sal_bac, !(X.SampleID %in% c("CatNC", "NC", "NRA.NegC", "RIM.NegC")))

## If there are more taxa than in the tree you will have some taxa that don't have any sequences
## We need to remove those
sum(taxa_sums(Sal_bac_final) == 0)
Sal_bac_final <- filter_taxa(Sal_bac_final, function(x) sum(x) != 0, TRUE)
sum(taxa_sums(Sal_bac_final) == 0)

#####################   BASIC SUMMARY of DATA  ###################################

## Let's get some summary stats on how the data looks
## Total number of high-quality sequences
sum(sample_sums(Sal_bac_final))

## number of sequences per samples
sample_sums(Sal_bac_final)

####  distribution of reads per samples 
readsumsdf = data.frame(nreads = sort(sample_sums(Sal_bac_final),  TRUE), sorted = 1:nsamples(Sal_bac_final), type = "Samples")
ggplot(readsumsdf, aes(x = sorted, y = nreads)) + geom_bar(stat = "identity") #+ scale_y_log10() 

## Total number of OTUs
ntaxa(Sal_bac_final)

####  distribution of reads per OTU 
readsumsdf2 = data.frame(nreads = sort(taxa_sums(Sal_bac_final), TRUE), sorted = 1:ntaxa(Sal_bac_final), type = "OTUs")
ggplot(readsumsdf2, aes(x = sorted, y = nreads)) + geom_bar(stat = "identity")  
ggplot(readsumsdf2, aes(x = sorted, y = nreads)) + geom_bar(stat = "identity") + scale_y_log10()

## Make a taxonomy table and turn it into a dataframe to look at

tax_sal <- as(tax_table(Sal_bac_final), "matrix")
tax_sal_df <- as.data.frame(tax_sal)

# Number of phyla = 20 described phyla
unique(tax_sal_df$Phylum)

# Number of genera = 111 described genera
unique(tax_sal_df$Genus)

## number of OTUs in each Phylum
count(tax_sal_df$Phylum)

## From Muletz-Wolz et al. 2017 paper: "We generated 224,503 high quality bacterial sequences (342 bp average length) from
## 100 Plethodon salamander skin samples representing 480 OTUs from 20 described bacterial
## phyla. The taxonomic composition of OTUs consisted predominately of bacteria in six phyla
## (Proteobacteria: n = 198, Bacteroidetes: n = 83, Actinobacteria: n = 76, Firmicutes: n = 30,
## Acidobacteria: n = 41, Planctomycetes: n = 13). 

## Lots of Proteobacteria (198 OTUs) and Actinobacteria (76 OTUs), how abundant are they?
## Transform sequence counts to relative abundance = % sequences/ total sequences
Sal_RA = transform_sample_counts(Sal_bac_final, function(x) 100 * x/sum(x))

## We can see why it's of value to look at relative abundance
plot_bar(Sal_bac_final, fill = "Phylum")
## disregard warning message
plot_bar(Sal_RA, fill = "Phylum")

## We can also merge similar groups to make a more visually pleasing figure
## Merge all individuals that are the same species and sampled at the same park
Sal_park_sp <- merge_samples(Sal_bac_final, "Park.sp")

## Transform sequence counts after merging to relative abundance 
Sal_park_sp_RA = transform_sample_counts(Sal_park_sp, function(x) 100 * x/sum(x))
plot_bar(Sal_park_sp_RA, fill = "Phylum")
## Each line I think is an OTU
## Merge taxa to overcome this 
## Remember though that you merge at the Phylum level and can't look at a lower level now

Sal_park_sp_RA_phylum <- tax_glom(Sal_park_sp_RA, "Phylum")
plot_bar(Sal_park_sp_RA_phylum, fill = "Phylum")

## The number of distinct units increases as you go down the taxonomic ranks
## Which can make plotting challenging for diverse communities
Sal_park_sp_RA_class <- tax_glom(Sal_park_sp_RA, "Class")
plot_bar(Sal_park_sp_RA_class, fill = "Class")


## Back to our original file that is not merged and has RA per individual
## % Proteobacteria
ProteoRA = subset_taxa(Sal_RA, Phylum == "p__Proteobacteria")

mean(sample_sums(ProteoRA))
sd(sample_sums(ProteoRA))
var(sample_sums(ProteoRA))

 ## So 88% of sequences per individual on average are Proteobacteria +/- 7%

## The last of summary stats will be:
## What are the abundant genera within Proteobacteria
AcineRA = subset_taxa(Sal_RA, Genus == "g__Acinetobacter")
mean(sample_sums(AcineRA))
sd(sample_sums(AcineRA))
ntaxa(AcineRA)

PseudRA = subset_taxa(Sal_RA, Genus == "g__Pseudomonas")
mean(sample_sums(PseudRA))
sd(sample_sums(PseudRA))
ntaxa(PseudRA)

## From paper: "Some taxonomic groups were abundant, such
## as Proteobacteria that had an average relative abundance of 87% per individual (SD ± 7) and
## Actinobacteria representing an average relative abundance of 10% (SD ± 5). Most notable were
## Acinetobacter and Pseudomonas within the phylum Proteobacteria, as they were widely
## distributed across species, sites and localities (Table 2) and dominant in abundance
## (Acinetobacter, average = 44%, SD ± 18, total OTUs = 5; Pseudomonas, average = 32%, SD ±
## 21, total OTUs = 7). 

## Before we finish here let's estimate alpha diversity and add a column in the mapping
## file with alpha diversity, when we do analyses we can just import that as the 
## mapping file


############     NOTE: RAREFACTION/NORMALIZATION DEBATE      #######
## McMurdie & Holmes (2014) say "...Rarefying Microbiome Data Is Inadmissible" (http://journals.plos.org/ploscompbiol/article?id=10.1371/journal.pcbi.1003531)
## Weiss et al. (2017) 
## (https://microbiomejournal.biomedcentral.com/articles/10.1186/s40168-017-0237-y)
## My take is that it depends on your library sizes across samples, if greater than 10x difference you
## should rarefy to the lowest sequence count per sample, and potentially throw away some low coverage
## samples to not remove too much data
## Or you can use different normalization procedures:

## I used cumulative sum scaling to normalize my sequence counts
## Paulson et al. (2013) (http://www.nature.com/nmeth/journal/v10/n12/full/nmeth.2658.html?foxtrotcallback=true)
## One of the authors of this publication was a committee member on my dissertation
## See Extra_normalization.R if you would like to use this approach

## It looks like QIIME 2.0 is endorsing rarefying for alpha- and beta-diversity analyses,
## And then using ANCOM for differential abundance testing
## We will not cover differential abundance testing in this tutorial

## For simplicity and time sake, in analyses we will use raw sequence counts
## meaning non-rarefied, non-normalized dataset
## If you have a rarified .biom file you can just bring that into phyloseq



##########################   Estimate Alpha-diversity   #####################
## Have to turn species x site matrix that phyloseq uses to a site x species matrix
## Transpose and make a matrix that package picante can use to calculate alpha-diversity
site_species <-t(as(otu_table(Sal_bac_final), "matrix"))

## need to get rid of quotes in tree labels that fasttree adds
## Not a problem with new QIIME 2.0 tree files
tree$tip.label
tree$tip.label = gsub("'", "", tree$tip.label, fixed=TRUE)

prunedTree <- prune.sample(site_species,tree)

?pd
## Calculates both Faith's phylogenetic diversity (PD) and species richness (SR)
alpha <- pd(site_species, prunedTree, include.root = F)

## need to have both alpha and mapping dataframe having the same column info
alpha$X.SampleID <- row.names(alpha)

## phyloseq mapping file to a normal dataframe
meta <- as(sample_data(Sal_bac_final), "data.frame")

## now merge
alpha_meta <- merge(meta, alpha, by = "X.SampleID")

## Write a .txt file that you will import to work with in all future analyses as the 
## mapping file with alpha-diversity already estimated for you
## And the negative control samples are also removed

write.table(alpha_meta, "SMP_runall_Map_alpha.txt", sep = "\t", col.names = T, row.names = F)



