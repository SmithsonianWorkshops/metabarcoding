### Install all the packages we will need

###### Windows users
## Put the cursor at a line in black and run each line by hitting Ctrl + R

###### MAC users
## Put the cursor at a line in black and run each line by hitting Command + Return

# to install phyloseq, need to use bioconductor

source("https://bioconductor.org/biocLite.R")
# might say a newer version is available, but you don't need to upgrade

biocLite("phyloseq")

## Type 'a' to update all

## If asked: Do you want to install from sources the packages which need compilation?
## Type 'n' to not install from source

install.packages("ape", dependencies = T)
install.packages("vegan", dependencies = T)
install.packages("ggplot2", dependencies = T)
install.packages("picante", dependencies = T)
install.packages("plyr", dependencies = T)
install.packages("geomorph", dependencies = T)
install.packages("car", dependencies = T)



