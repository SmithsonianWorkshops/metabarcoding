####### Tutorial on PERMDISP analysis ##########
## By: Carly Muletz Wolz

## See Anderson & Walsh 2013: http://onlinelibrary.wiley.com/doi/10.1890/12-2010.1/abstract

## Similar to ANOVA, you should examine the dispersion of your factor groups (homogeneity of variance) 

# Now, I have heard the argument from a vegan workshop that you should test 
## for dispersion differences first and then not do PERMANOVA if dispersion is different. 
## Your choice. I like to visualize the data first, do a PERMANOVA, and if significant 
## determine if it is the centroid or the dispersion around the centroid driving it
## If the dispersion is different, the PERMANOVA could be significant because the
## dispersion is different AND the centroid is different. I use visualization of data
## to determine if centroid is different. In this example the centroid positions for the
## two sites at Shenandoah NP (LSB and RSB) clearly look far away from the centroid positions of
## the other three sites

library(ape)
library(phyloseq)
library(ggplot2)
library(vegan)

setwd("/Users/Carly/Dropbox (Smithsonian)/Metabarcode_wrksp/QIIME_files/")


######### Biom file  #######
biom <-  import_biom("otu_table_SMP_all.biom") 

#### Tree file #####
tree <- read.tree("SMP_rooted_all_Dec2015.tre")

##### Mapping file ####
map <- import_qiime_sample_data("SMP_runall_Map_alpha.txt")

## Merge into phyloseq object
Sal_bac_final <- merge_phyloseq(biom, tree, map)


####################  Co-occurring dataset analyses #########################
## The objective here was to:
## to determine the relative contribution of host species versus shared environment 
## in shaping skin microbiomes of sympatric species

Co_occur <- subset_samples(Sal_bac_final, Site.sp_compare == "Y")

## Because we subsetted some taxa are still present even though they don't have any sequences
sum(taxa_sums(Co_occur) == 0)
## Let's remove them in case they cause problems somewhere
Co_occur = filter_taxa(Co_occur, function(x) sum(x) != 0, TRUE)
sum(taxa_sums(Co_occur) == 0)

## Phyloseq objects are complex (Sal_bac_final), many of the packages just need a regular ole' data.frame
Co_df <- as(sample_data(Co_occur), "data.frame")

Co_df

## Jaccard distances
jacc <- distance(Co_occur, "jaccard", binary = T)
jacc.ord <-ordinate(Co_occur, method = "PCoA", jacc)

## Use betadisper to test dispersion, which is PERMDISP

## For PERMDISP, H0: ‘‘the average within-group dispersion (measured by the average distance to group centroid and as defined in the space of the chosen resemblance measure), is equivalent among the groups

## define our groups we care about
groups <- Co_df[["Site"]]

levels(groups)

## calculate the dispersion from the centroid for each group
mod <- betadisper(jacc, groups)

## test if different
anova(mod)

## the dispersion is different among sites
## let's look at it
plot(mod)

## Vegan developer, Gavin Simpson, said he would work on code to add group labels to this plot, 
## doesn't exist yet though....
## NICE, he did it
## Link: http://www.fromthebottomoftheheap.net/2016/04/17/new-plot-default-for-betadisper/

## Can do some fancy stuff with this plot function now!
plot(mod, hull = FALSE, ellipse = TRUE)

## You can see that distances are different among the groups (well, maybe if you squint)
boxplot(mod)


## whose different from who
mod.HSD <- TukeyHSD(mod)
mod.HSD
plot(mod.HSD)
## You have to stretch the plotting window to see all the pairwise comparisons
## RIM and LSB have marginally different dispersion

## While the centroid distances look different,
## it is unclear if the PERMANOVA was significant due to centroid distance or dispersion

## There is currently no test to differentiate between the two if 
## PERMANOVA gives a significant value


## Visually it looks like the centroid position is driving the significance
## Over the dispersion of the data, and you could report that in a paper

## The dispersion is telling you how diverse the community is for your factor (site)
## compared to all the other replicates of that particular site
## In this example, LSB has greater variation in the bacterial community present than RIM

## The centroid is tellin you how distinct the community at a particular site is
## compared to all other sites

## SO, we conclude that the skin microbiomes of salamanders occupying sites at 
## Shenandoah NP are distinct from the skin microbiomes of salamanders occupying
## sites at Catoctin MP and Mt. Roger's NRA. I chose not to discuss the dispersion 
## in the publication, but a reviewer asked about it. I was able to say that the
## centroids were driving the trend more than the dispersion.
