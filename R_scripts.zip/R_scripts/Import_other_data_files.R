### If you have data in different format than QIIME 

# load phyloseq
library(phyloseq)

## mothur files
## https://www.rdocumentation.org/packages/phyloseq/versions/1.16.2/topics/import_mothur
## import a shared file and a table file
## You can also convert mothur files to QIIME format and bring them in
## like we did in Part1

shared <- import_mothur(mothur_shared_file = "X.shared")

## Then you would merge with your mapping file and tree file that you would bring in
## like we did in Part1_Import_Summary_Alpha.R
merged <- merge_phyloseq(shared, tree, map)


### Let's work with the Global Patterns dataset
# get dataset
data(GlobalPatterns)

`?`(GlobalPatterns)
######  Let's reduce and decompose the Global patterns dataset to see what these files look like #####

# too big, reduce to work with
GP2 = prune_taxa(taxa_sums(GlobalPatterns) > 1000, GlobalPatterns)

sample_data(GP2)

# Get top 10 genera
top10genus = sort(tapply(taxa_sums(GP2), tax_table(GP2)[, "Genus"], sum), TRUE)[1:10]
GP3 = subset_taxa(GP2, Genus %in% names(top10genus))
GP3

#write files to use 
# Phyloseq uses matrix as species x site, most people make them as site x species
species_site <-as(otu_table(GP3), "matrix")
site_species <- t(species_site)

# taxon table 
tax <- as(tax_table(GP3), "matrix")
sample_data <- as(sample_data(GP3), "data.frame")

getwd()
## set your working directory to store these files, you can then open 
## them in excel to see what they look like
setwd("/Users/Carly/Desktop/")
write.csv(site_species, "GP_site_species.csv")
write.csv(tax, "GP_taxonomy.csv")
write.csv(sample_data, "GP_meta.csv")

## Now that we decomposed them into 'normal' files, let's bring them back in 
## and turn them back into phyloseq compatible files

# this is site by species matrix, need row.names = 1 to have phyloseq read it
site_species <- read.csv("GP_site_species.csv", header = T, row.names = 1)

# transpose to get a species x site matrix
species_site_transposed <- t(site_species)

# NEVER use numbers as a name for Column or Row label in R, R puts an X in front of it

# get rid of Xs that were inserted in front of numbers row.names
rownames(species_site_transposed) <- gsub("X","",row.names(species_site_transposed))

# need this to be a matrix
class(species_site_transposed)

# make compatible for phyloseq format
species_site_final = otu_table(species_site_transposed, taxa_are_rows = TRUE)

# Read taxonomy info in 
taxonomy <- read.csv("GP_taxonomy.csv", row.names = 1)

# Needs to be a matrix
class(taxonomy)
taxonomy <- as.matrix(taxonomy)

# Make compatible for phyloseq
taxonomy_final = tax_table(taxonomy)

meta_data <- read.csv("GP_meta.csv", header = T, row.names = 1)
# dataframe is expected for sample_data
class(meta_data)

# make compatible for phyloseq
meta_final <- sample_data(meta_data)

# good to go

# You can also add a phylogenetic tree here, if you have one

# Merge it all together

Our_GP_data <- merge_phyloseq(species_site_final, taxonomy_final, meta_final)

Our_GP_data




