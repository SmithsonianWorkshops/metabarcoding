####### Tutorial on microbiome data analysis ##########
## By: Carly Muletz Wolz

## Great website for stats guidance: GUSTA ME (http://mb3is.megx.net/gustame)
## Helpful papers: Ramette 2007 https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2121141/
## Paliy & Shankar 2016: https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4769650/


library(ape)
library(phyloseq)
library(vegan)
library(car)

setwd("/Users/Carly/Dropbox (Smithsonian)/Metabarcode_wrksp/R_files/")


######### Biom file  #######
biom <-  import_biom("otu_table_SMP_all.biom") 

#### Tree file #####
tree <- read.tree("SMP_rooted_all_Dec2015.tre")

##### Mapping file ####
map <- import_qiime_sample_data("SMP_runall_Map_alpha.txt")

## Merge into phyloseq object
Sal_bac_final <- merge_phyloseq(biom, tree, map)

#########################    DATA ANALYSIS   ####################################

## Following analyses in Muletz Wolz et al. 2017: https://www.ncbi.nlm.nih.gov/pubmed/28682480
## In the analyses, I separated the dataset into two parts
## A co-occurring species dataset in which I sampled co-occurring species at three parks, with 1-2 sites per park
## An elevation dataset in which I sampled 1 species along an elevational gradient


####################  Co-occurring dataset analyses #########################
## The objective here was to:
## to determine the relative contribution of host species versus shared environment 
## in shaping skin microbiomes of sympatric species

Co_occur <- subset_samples(Sal_bac_final, Site.sp_compare == "Y")

## Because we subsetted some taxa are still present even though they don't have any sequences
sum(taxa_sums(Co_occur) == 0)
## Let's remove them in case they cause problems somewhere
Co_occur = filter_taxa(Co_occur, function(x) sum(x) != 0, TRUE)
sum(taxa_sums(Co_occur) == 0)

## Phyloseq objects are complex (Sal_bac_final), many of the packages just need a regular ole' data.frame
Co_df <- as(sample_data(Co_occur), "data.frame")

Co_df

## Jaccard distances
jacc <- distance(Co_occur, "jaccard", binary = T)

## Unifrac distances
uni <- distance(Co_occur, method = "unifrac")

## Bray curtis distance
bray <- distance(Co_occur, method = "bray")


######## DISTANCE-BASED linear models  ######

## From paper: "For quantitative measurements (body condition, soil pH, substrate temperature and
## leaf litter depth), we examined the effects of these environmental factors on beta-diversity using
##  distance-based linear modeling (function capscale in the package ‘vegan’) with stepwise AIC (Kueneman et al. 2014).

## Distance-based redundancy analysis using capscale
cap.jacc <- capscale(jacc ~  BodyCon + SoilpH+ Leaf.litter  + Tsubst, data = Co_df)
cap.bray <- capscale(bray ~  BodyCon + SoilpH+ Leaf.litter  + Tsubst, data = Co_df)
cap.uni <- capscale(bray ~  BodyCon + SoilpH+ Leaf.litter  + Tsubst, data = Co_df)

## Test that the model is ok, with no colinear variables that would violate stat assumptions
## "variance inflation factor" or VIF.  A large VIF implies that the variable is 
## redundant with other variables in the data set.
## The definition of ‘high’ is somewhat arbitrary but values in the range of 5-10 are commonly used.
vif(cap.jacc)
vif(cap.bray)
vif(cap.uni)


plot(cap.jacc)
plot(cap.bray)
plot(cap.uni)

## Make null models
m0_ss <- capscale(jacc ~1, Co_df)
m0_u_ss <- capscale(uni ~1, Co_df)
m0_b_ss <- capscale(bray ~1, Co_df)

## Do step-wise regression
mod_ss <- step(m0_ss, scope = formula(cap.jacc), test = "perm")
mod_ss

## The final model is written in Call:
## And has the lowest AIC by 2
## The proportion explained by the constrained ordiation is 12.944% 
## From paper: "Soil pH was the significant factor correlated with presence-absence
## compositional changes (Jaccard and Unifrac), and it explained 13% of overall variation.

mod_uss <- step(m0_u_ss, scope = formula(cap.uni), test = "perm")
mod_uss

## Let's look at adundance-weighted Bray metric
mod_bss <- step(m0_b_ss, scope = formula(cap.bray), test = "perm")

## The AIC scores are nearly the same with and without BodyCon, and with and 
## without BodyCon are not significant based on p-value

## This outputs with formula with BodyCon in it
mod_bss

## Let's remove body condition since it doesn't appear to be significant

mod_bray_final <- capscale(bray ~SoilpH + Leaf.litter, Co_df)
mod_bray_final

## From paper: "Soil pH (range: 4 – 6.5) and leaf litter depth
## (range: 1.5 – 4.1 mm) were the significant factors associated with changes in abundance-
## weighted bacterial composition (Bray-Curtis, distance-based linear model: p < 0.05), explaining
## 51% of overall variation." 
## (Note we get 60% here because we aren't using the normalized sequence
## counts, but the raw counts -- see Extra_normalization.R on how to get normalized counts or use
## a rarefied dataset depending on your preference)



