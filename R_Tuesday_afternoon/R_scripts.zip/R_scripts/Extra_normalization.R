####### Tutorial on normalization procedure ##########
## By: Carly Muletz Wolz

## Based on: Paulson et al. (2013) (http://www.nature.com/nmeth/journal/v10/n12/full/nmeth.2658.html?foxtrotcallback=true)

source("https://bioconductor.org/biocLite.R")
biocLite("metagenomeSeq")

library(metagenomeSeq)
library(phyloseq)
library(ape)
setwd("/Users/Carly/Dropbox (Smithsonian)/Metabarcode_wrksp/QIIME_files/")


######### Biom file  #######
biom <-  import_biom("otu_table_SMP_all.biom") 

#### Tree file #####
tree <- read.tree("SMP_rooted_all_Dec2015.tre")

##### Mapping file ####
map <- import_qiime_sample_data("SMP_runall_Map.txt")

## Merge into phyloseq object
Sal_bac <- merge_phyloseq(biom, tree, map)

## Housekeeping, remove NC samples
Sal_bac_final <- subset_samples(Sal_bac, !(X.SampleID %in% c("CatNC", "NC", "NRA.NegC", "RIM.NegC")))

## Remove residual taxa that don't have any sequences
sum(taxa_sums(Sal_bac_final) == 0)
Sal_bac_final <- filter_taxa(Sal_bac_final, function(x) sum(x) != 0, TRUE)
sum(taxa_sums(Sal_bac_final) == 0)

## Convert file types to use in metagenomeSeq
MGS <- phyloseq_to_metagenomeSeq(Sal_bac_final)

MGS

p <- cumNormStatFast(MGS)
p
MGS <- cumNorm(MGS, p =p)

# returns normalized factors for each sample
head(normFactors(MGS))

# To export normalized count matrix
normmybiom_ss <- MRcounts(MGS, norm = T)

## now write this as an OTU table 
species_site_final <- otu_table(normmybiom_ss, taxa_are_rows = TRUE)
## Get tax and meta data files, so I can merge a new file that has normalized counts

tax_ss <- as(tax_table(Sal_bac_final), "matrix")
class(tax_ss)
# Make compatible for phyloseq
taxonomy_final_ss = tax_table(tax_ss)

Sal_bac_final <- merge_phyloseq(species_site_final, taxonomy_final_ss, map,tree)
