####### Tutorial on microbiome data analysis ##########
## By: Carly Muletz Wolz

## Great website for stats guidance: GUSTA ME (http://mb3is.megx.net/gustame)
## Helpful papers: Ramette 2007 https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2121141/
## Paliy & Shankar 2016: https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4769650/


library(ape)
library(phyloseq)
library(ggplot2)
library(car)
library(plyr)
library(vegan)

## Set working directory to your local directory

## Mac example:
# setwd("/Users/Carly/Dropbox (Smithsonian)/Metabarcode_wrksp/R_files/")

## PC example:
# setwd("C:/Users/muletzc/Documents/Metabarcode_wrkshp/R_files/")

######### Biom file  #######
biom <-  import_biom("otu_table_SMP_all.biom") 

## Add OTU_ID to taxonomy table
tax_table(biom) <- cbind(tax_table(biom), rownames(tax_table(biom)))

## Specify the column names
colnames(tax_table(biom)) <- c("Kingdom", "Phylum", "Class", "Order", "Family", "Genus", "Species", "OTUID")
rank_names(biom)

#### Tree file #####
tree <- read.tree("SMP_rooted_all_Dec2015.tre")

##### Mapping file ####
map <- import_qiime_sample_data("SMP_runall_Map_alpha.txt")

## Merge into phyloseq object
Sal_bac_final <- merge_phyloseq(biom, tree, map)

## Remove residual taxa that don't have any sequences
sum(taxa_sums(Sal_bac_final) == 0)
Sal_bac_final <- filter_taxa(Sal_bac_final, function(x) sum(x) != 0, TRUE)
sum(taxa_sums(Sal_bac_final) == 0)

#########################    DATA ANALYSIS   ####################################

## Following analyses in Muletz Wolz et al. 2017: https://www.ncbi.nlm.nih.gov/pubmed/28682480
## In the analyses, I separated the dataset into two parts
## A co-occurring species dataset in which I sampled co-occurring species at three parks, with 1-2 sites per park
## An elevation dataset in which I sampled 1 species along an elevational gradient


####################  Co-occurring dataset analyses #########################
## The objective here was to:
## to determine the relative contribution of host species versus shared environment 
## in shaping skin microbiomes of sympatric species

Co_occur <- subset_samples(Sal_bac_final, Site.sp_compare == "Y")

## Because we subsetted some taxa are still present even though they don't have any sequences
sum(taxa_sums(Co_occur) == 0)
## Let's remove them in case they cause problems somewhere
Co_occur = filter_taxa(Co_occur, function(x) sum(x) != 0, TRUE)
sum(taxa_sums(Co_occur) == 0)

## Phyloseq objects are complex (Sal_bac_final), many of the packages just need a regular ole' data.frame
Co_df <- as(sample_data(Co_occur), "data.frame")

head(Co_df)

### Alpha_diversity
summary(Co_df$SR)
sd(Co_df$SR)

summary(Co_df$PD)
sd(Co_df$PD)

## From paper: "On average, bacterial alpha-diversity was 59 OTUs per salamander (SD ±18) and a
## Faith’s PD of 4.4 (SD ± 1.3), regardless of species or site.

## Visualize alpha-diversity
p_alpha1 <- ggplot(data = Co_df, aes(x = Species, y = SR)) + geom_boxplot()
p_alpha1

## Let's compare across the different parks sampled
p_alpha1 + facet_wrap(~ Park, ncol =3)

## Each park had 1-2 sites sampled
p_alpha2 <- ggplot(data = Co_df, aes(x = Species, y = SR, color = Park)) + geom_boxplot()
p_alpha2
p_alpha2 + facet_wrap(~ Site, ncol =3)

## sample sizes of salamanders per park species combination
table(Co_df$Park.sp)

## How about using ddply (from package plyr) to summarize
## This is a great function to get to know your data
ddply(Co_df, ~ Park.sp, summarize, n = length(Park.sp), Avg_alpha = mean(SR), sd = sd(SR), se = sd(SR)/sqrt(length(SR)))

##############      Alpha-diversity stats   ##############
## From paper: "For alpha-diversity, we used generalized linear models (GLM) to examine 
## variation in (i) total number of observed OTUs using a quasipoisson distribution to 
## account for overdispersed count data and (ii) Faith’s PD using a log-transformation 
## to achieve normality.

## I generally plot a histogram of my response variable to think about
## what models to run and how to transform the data if need be
## While species richness distribution is not normal
hist(Co_df$SR)
## it is a count, and the distribution should be poisson
## Therefore, we should not log-transform it 
## http://onlinelibrary.wiley.com/doi/10.1111/j.2041-210X.2010.00021.x/full


## We see that it is an integer
str(Co_df$SR)

## From paper: "We included species and site as the main explanatory variables, 
## in addition to covariates of host (sex, body condition, cover object, substrate 
## temperature) and site (leaf litter depth, soil pH). 

m_co <- glm(SR ~ Site + Species + sex + BodyCon + Leaf.litter + Object + SoilpH + Tsubst, 
            family = poisson, data = Co_df)

## The residual deviance is much higher than degrees of freedom
## suggests that the model is overdispersed
summary(m_co)

## From paper: "We performed deviance goodness of fit tests for each model to assess 
## model fit, and we determined significance 
## of variables using the anova function with X2 as the test statistic."

## Assess model fit with deviance goodness-of-fit test
## Test to see if overdispersed, p < 0.05 is overdispersed = Highly overdispersed
## https://stats.idre.ucla.edu/r/dae/poisson-regression/
with(m_co, cbind(res.deviance = deviance, df = df.residual,
                 p = pchisq(deviance, df.residual, lower.tail=FALSE)))

## More appropriate to use a quasipoisson model to deal with overdispersed data
m_co_quasi <- glm(SR ~ Site + Species + sex + BodyCon + Leaf.litter + Object + SoilpH + Tsubst, 
            data = Co_df, family = quasipoisson)

## determine significance of variables in model using type I sum of squares
## (Terms added sequentially) = order matters
## Model selection is also a choice
## Useful site, but focuses on mixed models (fixed and random effects):
## http://bbolker.github.io/mixedmodels-misc/glmmFAQ.html
anova(m_co_quasi, test = "Chisq")


## SoilpH is co-linear with Site (Df = 0, deviance = 0 is a flag)
## and should have been removed in the original model
## Didn't realize that until just now...
## The model stays the same though, as it recognizes the colinearity and 
## removes the soilpH term

## Publication figure for species richness using package ggplot2
## ggplot2 is awesome! and well-documented on how to edit figures: http://www.cookbook-r.com/Graphs/
plot1_r <- ggplot(data = Co_df, aes(y = SR, x = Species, fill = Site)) + geom_boxplot()

plot1_r
## Not really publication quality
## Add a bunch of qualifiers, I just googled searched until the figure looked good
## Used colors that could work in black and white

## For instance, remove background color and give it a 'classic' look
plot1_r+ theme_bw() + theme_classic()

## Change font size, etc.
plot1_r+ theme_bw() + theme_classic() +theme(text = element_text(size = 16))

## Add labels, you can put in \n before and after text to put a space in
plot1_r + labs(y = "Bacterial OTUs / salamander", x = "Species")
plot1_r + labs(y = "Bacterial OTUs / salamander\n", x = "\nSpecies")

## change factor level of sites, so that it follows an order
## FDR was the one site at Catoctin MP, LSB and RSB were sampling sites at Shenandoah NP
## NRA and RIM were sampling sites at Mt. Rogers. We will also rename them 
## when we plot them later on so they are more informative to someone else other than me!
levels(Co_df$Site) 
Co_df$Site <- factor(Co_df$Site, levels = c("FDR", "LSB", "RSB", "NRA", "RIM"))
levels(Co_df$Site) 

plot1_r2 <- ggplot(data = Co_df, aes(y = SR, x = Species, fill = Site)) + geom_boxplot()

## All the bells and whistles!
plot1_r2 + labs(y = "Bacterial OTUs / salamander\n", x = "\nSpecies") + theme_bw() + theme_classic() + 
  theme(text = element_text(size = 16)) + scale_fill_manual(values = c( "steelblue4", "mediumpurple2", "coral", "turquoise", "yellow"), 
  labels = c("Catoctin", "Shenandoah1", "Shenandoah2", "Mt.Rogers1", "Mt.Rogers2"))  +
  theme(axis.title.x = element_text(vjust=-0.35)) +  theme(axis.text.x = element_text(face = "italic")) + 
  scale_x_discrete(labels =  c("P. cinereus", "P. cylindraceus", "P. glutinosus")) 

## We will look again at ggplot2 graphics in Part3

####### Phylogenetic diversity (PD)
## defined as the minimum total length of all the phylogenetic branches 
## required to span a given set of taxa on the phylogenetic tree (Faith 1992). 
## Larger PD values can be expected to correspond to greater expected feature diversity

## For phylogenetic diversity this is a numeric variable
str(Co_df$PD)

## Make histograms
hist(Co_df$PD)

## see if normally distributed or if log transformation works
## P < 0.05 not normal
shapiro.test(Co_df$PD)
shapiro.test(log(Co_df$PD))

## Homogeneity of variance?
## Primary focus is on effects of host species and of site, must do
## separate since not fully crossed
## p > 0.05 equal variances
leveneTest(log(PD) ~ Site, data = Co_df)
leveneTest(log(PD) ~ Species, data = Co_df)

### Meet assumptions of linear model with log transformation of Faith's PD 
m_pd <- lm(log(PD) ~ Site + Species + sex + BodyCon + Leaf.litter + Object + Tsubst, 
           data = Co_df)

## Evaluate how the model fit, hit RETURN after clicking in console
## to see 4 different plots
## No pattern in residuals vs. fitted = good
## Approximately linear fit in Normal Q-Q plot = good
## I forget what the other two plots tell you...
plot(m_pd)

## determine significance of variables in model using type I sum of squares
anova(m_pd, test = "Chisq")


####################  Elevation dataset analyses #########################
## The objective here was to:
## to determine whether elevation can predict microbiome structure

## From paper: "For alpha-diversity, we used GLMs to examine variation in total number of observed OTUs and
## Faith's PD using quasipoisson and Gaussian distributions, respectively. We included elevation as
## the explanatory variable in addition to co-variates of host (sex, body condition, cover object,
## substrate temperature) and site (leaf litter depth, soil pH) characteristics and assessed model fit
## and significance of variables as above."


Elev <- subset_samples(Sal_bac_final, Species == "cinereus" & Park == "Shenandoah")


## Because we subsetted some taxa are still present even though they don't have any sequences
sum(taxa_sums(Elev) == 0)
## Let's remove them in case they cause problems somewhere
Elev = filter_taxa(Elev, function(x) sum(x) != 0, TRUE)
sum(taxa_sums(Elev) == 0)


## Make dataframe
Ele_df <- as(sample_data(Elev), "data.frame")

## Summary
summary(Ele_df$SR)
mean(Ele_df$SR)
sd(Ele_df$SR)

ddply(Ele_df, ~ Elevation, summarize, n = length(SR), Avg_alpha = mean(SR), sd = sd(SR), se = sd(SR)/sqrt(length(SR)))

## Will just look at species richness in this case
hist(Ele_df$SR)

##see if normally distributed
shapiro.test(Ele_df$SR)

m_ele <- glm(SR~  Elevation  + Object + SoilpH + Tsubst +BodyCon + Leaf.litter, data = Ele_df, family = poisson)
## Overdispersed
summary(m_ele)

## Quasipoisson to account for overdispersion
m_ele_q <- glm(SR~  Elevation  + Object + SoilpH + Tsubst +BodyCon + Leaf.litter, data = Ele_df, family = quasipoisson)
anova(m_ele_q, test = "Chisq")

## Terms are added sequentially let's move them around to make sure they are truly significant
## We keep Elevation at the beginning as we are most interested in that and hypothesized that
## alpha-diversity would change with Elevation
m_ele_q2 <- glm(SR~  Object + Elevation + Leaf.litter + SoilpH + Tsubst +BodyCon , data = Ele_df, family = quasipoisson)
anova(m_ele_q2, test = "Chisq")

m_ele_q3 <- glm(SR~  Elevation+ Leaf.litter + SoilpH +BodyCon +Object + Tsubst   , data = Ele_df, family = quasipoisson)
anova(m_ele_q3, test = "Chisq")

## Elevation remains significant, but SoilpH and Leaf.litter do not always
## I reported the significance of Elevation and explored how soilPh and leaf.litter
## affected beta-diversity in later analyses

## I confirmed a relationship looking at a basic linear model also
m_ele_lm <- lm(log(SR) ~ Elevation, data = Ele_df)
summary(m_ele_lm)


#############   FINAL FIGURE   ##############
p_ele <-  ggplot(data = Ele_df, aes(x = Elevation, y = SR)) +theme_bw()+ theme_classic() + 
  stat_smooth(method = lm, se = T, color = "black") + geom_point() + theme(text = element_text(size = 16)) +
  xlab("\nElevation (m)") +ylab("OTU richness\n") 
p_ele

